# coding: utf-8
# Copyright (c) 2012-2013 Raphaël Barrois
# This code is distributed under the LGPLv3 License.

__author__ = u"Raphaël Barrois <raphael.barrois+djadmin-export@polytechnique.org>"
__version__ = '0.1.3'
